# ANN_SimplyExplained
Used ANN to find out whether customer will exit form bank or not ?
